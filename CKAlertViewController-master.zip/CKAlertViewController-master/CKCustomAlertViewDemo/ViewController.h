//
//  ViewController.h
//  CKCustomAlertViewDemo
//
//  Created by 陈凯 on 16/9/7.
//  Copyright © 2016年 陈凯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

